package clusterize_finalization

import (
	"context"
)

func ClusterizeFinalization(ctx context.Context, region, instanceGroup, bucket string) (err error) {

	return
}
